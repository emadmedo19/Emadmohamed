import 'package:flutter/material.dart';

void main() => runApp(const BonianApp());

const navy = Color(0xFF172B4D);
const teal = Color(0xFF168C83);
const pale = Color(0xFFF4F7FA);
const ink = Color(0xFF243247);
const muted = Color(0xFF7B8798);

class BonianApp extends StatelessWidget {
  const BonianApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'بُنيان',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: pale,
        colorScheme: ColorScheme.fromSeed(seedColor: teal, primary: teal),
        fontFamily: 'Cairo',
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white, foregroundColor: ink,
          elevation: 0, centerTitle: false,
        ),
        cardTheme: CardThemeData(
          color: Colors.white, elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        ),
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int selected = 0;
  final pages = const [
    DashboardPage(), ApartmentsPage(), CollectionsPage(), ReportsPage(), MorePage()
  ];
  final titles = ['الرئيسية', 'الشقق والسكان', 'التحصيلات', 'التقارير', 'المزيد'];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Row(children: [
            Image.asset('assets/images/branding/bonyan_mark.png', width: 34, height: 34,
              errorBuilder: (_, __, ___) => const Icon(Icons.apartment, color: teal)),
            const SizedBox(width: 9),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('بُنيان', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 19)),
              Text(titles[selected], style: const TextStyle(fontSize: 11, color: muted)),
            ]),
          ]),
          actions: [
            IconButton(onPressed: () => _toast(context, 'لا توجد إشعارات جديدة'),
              icon: const Icon(Icons.notifications_none_rounded)),
            const SizedBox(width: 5),
          ],
        ),
        body: IndexedStack(index: selected, children: pages),
        bottomNavigationBar: NavigationBar(
          selectedIndex: selected,
          onDestinationSelected: (i) => setState(() => selected = i),
          backgroundColor: Colors.white,
          indicatorColor: teal.withOpacity(.12),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.apartment_outlined), selectedIcon: Icon(Icons.apartment), label: 'الشقق'),
            NavigationDestination(icon: Icon(Icons.payments_outlined), selectedIcon: Icon(Icons.payments), label: 'التحصيل'),
            NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart), label: 'التقارير'),
            NavigationDestination(icon: Icon(Icons.grid_view_rounded), selectedIcon: Icon(Icons.grid_view), label: 'المزيد'),
          ],
        ),
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [navy, Color(0xFF285477)],
            begin: Alignment.topRight, end: Alignment.bottomLeft),
          borderRadius: BorderRadius.circular(22),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('أهلاً بيك 👋', style: TextStyle(color: Colors.white70, fontSize: 14)),
          const SizedBox(height: 3),
          const Text('إدارة عمارتك بقت أسهل', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.bold)),
          const SizedBox(height: 18),
          Row(children: [
            const Icon(Icons.apartment, color: Colors.white70),
            const SizedBox(width: 7),
            const Expanded(child: Text('عمارة النخيل', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
            Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(color: Colors.white.withOpacity(.15), borderRadius: BorderRadius.circular(20)),
              child: const Text('العمارة الحالية', style: TextStyle(color: Colors.white, fontSize: 10))),
          ]),
        ]),
      ),
      const SizedBox(height: 18),
      const SectionHeading('ملخص العمارة', subtitle: 'نظرة سريعة على الوضع المالي'),
      const SizedBox(height: 10),
      const Row(children: [
        Expanded(child: StatCard(title: 'إجمالي التحصيل', value: '٢٤,٥٠٠ ج.م', icon: Icons.account_balance_wallet_outlined, color: teal, foot: 'هذا الشهر')),
        SizedBox(width: 10),
        Expanded(child: StatCard(title: 'المصروفات', value: '٨,٧٥٠ ج.م', icon: Icons.receipt_long_outlined, color: Color(0xFFE59A36), foot: 'هذا الشهر')),
      ]),
      const SizedBox(height: 10),
      const Row(children: [
        Expanded(child: StatCard(title: 'الشقق', value: '٢٤', icon: Icons.door_front_door_outlined, color: Color(0xFF5279C7), foot: 'إجمالي الوحدات')),
        SizedBox(width: 10),
        Expanded(child: StatCard(title: 'مبالغ متأخرة', value: '٣,٢٠٠ ج.م', icon: Icons.pending_actions, color: Color(0xFFD66A6A), foot: 'مستحقات السكان')),
      ]),
      const SizedBox(height: 20),
      const SectionHeading('إجراءات سريعة', subtitle: 'اختصارات للمهام اليومية'),
      const SizedBox(height: 10),
      GridView.count(
        crossAxisCount: 4, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 12, crossAxisSpacing: 8, childAspectRatio: .82,
        children: [
          QuickAction(icon: Icons.add_card, label: 'تسجيل تحصيل', onTap: () => _toast(context, 'إضافة تحصيل جديد')),
          QuickAction(icon: Icons.add_business, label: 'مصروف جديد', onTap: () => _toast(context, 'إضافة مصروف جديد')),
          QuickAction(icon: Icons.person_add_alt_1, label: 'إضافة ساكن', onTap: () => _toast(context, 'إضافة ساكن جديد')),
          QuickAction(icon: Icons.build_outlined, label: 'طلب صيانة', onTap: () => _toast(context, 'تسجيل طلب صيانة')),
        ],
      ),
      const SizedBox(height: 18),
      const SectionHeading('آخر الحركات', subtitle: 'أحدث العمليات المسجلة'),
      const SizedBox(height: 8),
      const ActivityTile(title: 'تحصيل اشتراك شهر أكتوبر', subtitle: 'الشقة ١٢ • أحمد محمد', amount: '+ ١,٠٠٠ ج.م', positive: true, icon: Icons.arrow_downward),
      const ActivityTile(title: 'صيانة المصعد', subtitle: 'مصروفات صيانة • اليوم', amount: '− ٧٥٠ ج.م', positive: false, icon: Icons.build_outlined),
      const ActivityTile(title: 'تحصيل نظافة', subtitle: 'الشقة ٧ • محمد علي', amount: '+ ٣٠٠ ج.م', positive: true, icon: Icons.arrow_downward),
      const SizedBox(height: 12),
    ]);
  }
}

class StatCard extends StatelessWidget {
  final String title, value, foot;
  final IconData icon;
  final Color color;
  const StatCard({super.key, required this.title, required this.value, required this.icon, required this.color, required this.foot});
  @override
  Widget build(BuildContext context) => Card(child: Padding(
    padding: const EdgeInsets.all(14),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Icon(icon, color: color, size: 20), const Spacer(), Text(foot, style: const TextStyle(color: muted, fontSize: 10))]),
      const SizedBox(height: 12),
      Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: ink)),
      const SizedBox(height: 2),
      Text(title, style: const TextStyle(color: muted, fontSize: 11)),
    ]),
  ));
}

class SectionHeading extends StatelessWidget {
  final String title;
  final String? subtitle;
  const SectionHeading(this.title, {super.key, this.subtitle});
  @override
  Widget build(BuildContext context) => Row(children: [
    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: ink)),
      if (subtitle != null) Text(subtitle!, style: const TextStyle(fontSize: 11, color: muted)),
    ])),
    const Icon(Icons.more_horiz, color: muted),
  ]);
}

class QuickAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const QuickAction({super.key, required this.icon, required this.label, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(
    borderRadius: BorderRadius.circular(14), onTap: onTap,
    child: Column(children: [
      Container(width: 54, height: 54, decoration: BoxDecoration(color: teal.withOpacity(.10), borderRadius: BorderRadius.circular(17)),
        child: Icon(icon, color: teal, size: 25)),
      const SizedBox(height: 6),
      Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10, color: ink, height: 1.3)),
    ]),
  );
}

class ActivityTile extends StatelessWidget {
  final String title, subtitle, amount;
  final bool positive;
  final IconData icon;
  const ActivityTile({super.key, required this.title, required this.subtitle, required this.amount, required this.positive, required this.icon});
  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.only(bottom: 8),
    child: ListTile(
      leading: CircleAvatar(backgroundColor: (positive ? teal : Colors.orange).withOpacity(.12),
        child: Icon(icon, color: positive ? teal : Colors.orange, size: 20)),
      title: Text(title, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
      subtitle: Text(subtitle, style: const TextStyle(fontSize: 10, color: muted)),
      trailing: Text(amount, style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: positive ? teal : Colors.deepOrange)),
    ),
  );
}

class ApartmentsPage extends StatelessWidget {
  const ApartmentsPage({super.key});
  @override
  Widget build(BuildContext context) => SimpleListPage(
    title: 'الشقق والسكان', description: 'إدارة الوحدات وبيانات السكان',
    icon: Icons.apartment, items: const [
      ('الشقة ١', 'الدور الأول • محمد أحمد • مشغولة'),
      ('الشقة ٢', 'الدور الأول • غير مشغولة'),
      ('الشقة ٣', 'الدور الثاني • سارة محمود • مشغولة'),
      ('الشقة ٤', 'الدور الثاني • غير مشغولة'),
      ('الشقة ٥', 'الدور الثالث • خالد حسن • مشغولة'),
    ], action: 'إضافة شقة',
  );
}

class CollectionsPage extends StatelessWidget {
  const CollectionsPage({super.key});
  @override
  Widget build(BuildContext context) => SimpleListPage(
    title: 'التحصيلات', description: 'متابعة الاشتراكات والمبالغ المستحقة',
    icon: Icons.payments_outlined, action: 'تسجيل تحصيل',
    items: const [
      ('اشتراك العمارة', 'الشقة ١٢ • ١,٠٠٠ ج.م • تم التحصيل'),
      ('النظافة', 'الشقة ٧ • ٣٠٠ ج.م • تم التحصيل'),
      ('الصيانة', 'الشقة ٤ • ٥٠٠ ج.م • مستحق'),
      ('حارس العقار', 'الشقة ٩ • ٢٠٠ ج.م • مستحق'),
    ],
  );
}

class ReportsPage extends StatelessWidget {
  const ReportsPage({super.key});
  @override
  Widget build(BuildContext context) => SimpleListPage(
    title: 'التقارير المالية', description: 'تقارير التحصيل والمصروفات والأرصدة',
    icon: Icons.analytics_outlined, action: 'عرض التقرير',
    items: const [
      ('ملخص الإيرادات والمصروفات', 'تقرير شهري'),
      ('كشف حساب شقة', 'تفاصيل الحركات والمديونيات'),
      ('حالة سداد الشقق', 'المسدد والمتأخر'),
      ('دفتر الحسابات', 'كل العمليات المالية'),
      ('تقرير سنوي للعمارة', 'ملخص السنة المالية'),
    ],
  );
}

class MorePage extends StatelessWidget {
  const MorePage({super.key});
  @override
  Widget build(BuildContext context) => SimpleListPage(
    title: 'المزيد', description: 'كل أدوات وخدمات إدارة العمارة',
    icon: Icons.grid_view_rounded, action: 'إعدادات التطبيق',
    items: const [
      ('المصروفات', 'تسجيل ومراجعة مصروفات العمارة'),
      ('طلبات الصيانة', 'متابعة البلاغات وحالة التنفيذ'),
      ('الموظفون', 'الحارس والعمال ومقدمو الخدمات'),
      ('المركبات والجراج', 'إدارة أماكن انتظار السيارات'),
      ('طلبات الانضمام', 'مراجعة طلبات السكان'),
      ('الإشعارات', 'تنبيهات السكان والإدارة'),
      ('الإعدادات', 'اللغة والخصوصية والمظهر'),
    ],
  );
}

class SimpleListPage extends StatelessWidget {
  final String title, description, action;
  final IconData icon;
  final List<(String, String)> items;
  const SimpleListPage({super.key, required this.title, required this.description, required this.icon, required this.items, required this.action});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    Card(child: Padding(padding: const EdgeInsets.all(18), child: Row(children: [
      CircleAvatar(radius: 27, backgroundColor: teal.withOpacity(.12), child: Icon(icon, color: teal, size: 27)),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        Text(description, style: const TextStyle(color: muted, fontSize: 11)),
      ])),
    ]))),
    const SizedBox(height: 12),
    FilledButton.icon(onPressed: () => _toast(context, '$action - واجهة تجريبية'),
      icon: const Icon(Icons.add), label: Text(action)),
    const SizedBox(height: 12),
    ...items.map((item) => Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: const CircleAvatar(backgroundColor: Color(0xFFEAF4F3), child: Icon(Icons.folder_open, color: teal)),
        title: Text(item.$1, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
        subtitle: Text(item.$2, style: const TextStyle(fontSize: 10, color: muted)),
        trailing: const Icon(Icons.chevron_left, color: muted),
        onTap: () => _toast(context, item.$1),
      ),
    )),
  ]);
}

void _toast(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message), behavior: SnackBarBehavior.floating));
}
